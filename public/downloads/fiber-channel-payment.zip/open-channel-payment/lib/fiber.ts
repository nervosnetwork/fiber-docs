import { createBrowserNodeSession, PeerHandshakeTimeoutError } from './browser-node-session';
import type { BrowserNodeState, FiberBrowserNode } from '@fiber-pay/sdk/browser';
export const routerPubkey = '0x02b6d4e3ab86a2ca2fad6fae0ecb2e1e559e0b911939872a90abdda6d20302be71';
const routerAddress = '/dns4/bottle.fiber.channel/tcp/443/wss/p2p/QmXen3eUHhywmutEzydCsW4hXBoeVmdET2FJvMX69XJ1Eo';
const profileKey = 'fiber-tutorial-profile-v1';
const toHex = (bytes: Uint8Array) => Array.from(bytes, (value) => value.toString(16).padStart(2, '0')).join('');
const fromHex = (value: string) => Uint8Array.from(value.match(/.{2}/g) ?? [], (part) => Number.parseInt(part, 16));
function profile() {
  const saved = localStorage.getItem(profileKey);
  if (saved) {
    const value = JSON.parse(saved);
    return { fiberKey: fromHex(value.fiberKey), ckbKey: fromHex(value.ckbKey), identifier: value.identifier };
  }
  const value = { fiberKey: toHex(crypto.getRandomValues(new Uint8Array(32))), ckbKey: toHex(crypto.getRandomValues(new Uint8Array(32))), identifier: crypto.randomUUID() };
  localStorage.setItem(profileKey, JSON.stringify(value));
  return { fiberKey: fromHex(value.fiberKey), ckbKey: fromHex(value.ckbKey), identifier: value.identifier };
}
export async function startFiber(onState: (state: BrowserNodeState) => void, session: ReturnType<typeof createBrowserNodeSession>) {
  if (!crossOriginIsolated) throw new Error('This page must be cross-origin isolated.');
  let started: FiberBrowserNode | undefined;
  await session.start(profileKey, async (track) => {
    const { FiberBrowserNode, RawKeyCredentialProvider } = await import('@fiber-pay/sdk/browser');
    const keys = profile();
    const node = new FiberBrowserNode({ network: 'testnet', credential: new RawKeyCredentialProvider(keys.fiberKey, keys.ckbKey, keys.identifier), nodeConfig: { bootnodes: [], logLevel: 'info' } });
    node.on('stateChange', onState);
    track(node);
    await node.start();
    started = node;
  });
  return started!;
}
export async function connectToRouter(node: FiberBrowserNode) {
  await node.connectPeer({ address: routerAddress, pubkey: routerPubkey });
  for (let attempt = 0; attempt < 10; attempt += 1) {
    if ((await node.listPeers()).peers.some((peer) => peer.pubkey === routerPubkey)) return;
    await new Promise((resolve) => setTimeout(resolve, 800));
  }
  throw new PeerHandshakeTimeoutError('Prepare browser node');
}
