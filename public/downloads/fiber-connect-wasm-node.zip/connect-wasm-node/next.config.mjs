/** @type {import('next').NextConfig} */
const nextConfig = {
  transpilePackages: ['@fiber-pay/sdk', '@nervosnetwork/fiber-js'],
  async headers() {
    return [{
      source: '/fiber',
      headers: [
        { key: 'Cross-Origin-Opener-Policy', value: 'same-origin' },
        { key: 'Cross-Origin-Embedder-Policy', value: 'require-corp' },
      ],
    }];
  },
};

export default nextConfig;
