import { createTestnetFiberFactory } from './fiber-testnet-runtime';
import { requireNewChannelFunding } from './channel-funding';
import type { FiberBrowserNode } from '@fiber-pay/sdk/browser';
export const bottle={pubkey:'0x02b6d4e3ab86a2ca2fad6fae0ecb2e1e559e0b911939872a90abdda6d20302be71' as const,address:'/dns4/bottle.fiber.channel/tcp/443/wss/p2p/QmXen3eUHhywmutEzydCsW4hXBoeVmdET2FJvMX69XJ1Eo'};
const hex=(v:Uint8Array)=>Array.from(v,b=>b.toString(16).padStart(2,'0')).join('');
const bytes=(v:string)=>Uint8Array.from(v.match(/../g)??[],x=>parseInt(x,16));
export const ckbToHex=(v:string)=>`0x${(BigInt(Math.round(Number(v)*1e8))).toString(16)}` as `0x${string}`;
export async function startFiber(key:string){const sdk=await import('@fiber-pay/sdk/browser');let raw=localStorage.getItem(key);if(!raw){raw=JSON.stringify({fiber:hex(crypto.getRandomValues(new Uint8Array(32))),ckb:hex(crypto.getRandomValues(new Uint8Array(32))),id:crypto.randomUUID()});localStorage.setItem(key,raw)}const value=JSON.parse(raw);const node=new sdk.FiberBrowserNode({wasmFactory: await createTestnetFiberFactory(),network:'testnet',credential:new sdk.RawKeyCredentialProvider(bytes(value.fiber),bytes(value.ckb),value.id),nodeConfig:{bootnodes:[],logLevel:'info'}});await node.start();return node;}
export async function prepareChannel(node:FiberBrowserNode){await node.connectPeer(bottle);const channels=(await node.listChannels()).channels;const existing=channels.find(c=>c.pubkey===bottle.pubkey&&!['CLOSED','SHUTTING_DOWN'].includes(c.state.state_name));if(existing)return existing;await requireNewChannelFunding(node);await node.openChannel({pubkey:bottle.pubkey,funding_amount:ckbToHex('500'),public:true});}
